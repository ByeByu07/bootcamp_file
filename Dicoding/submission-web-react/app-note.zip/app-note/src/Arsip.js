import React from "react";

const Arsip = () => {
  return (
    <div className="arsip__container">
      <section className="arsip__header">
        <header className="arsip__title">
          <h1>Arsip</h1>
        </header>
      </section>
    </div>
  );
};

export default Arsip;
